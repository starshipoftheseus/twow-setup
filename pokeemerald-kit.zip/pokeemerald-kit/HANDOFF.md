# Handoff prompt for a new Claude chat

Paste this into a new Claude Code session that has access to this repo:

> This repo is my pokeemerald-expansion starter kit (CLAUDE.md template, design/ templates,
> setup scripts, resource list in README.md). Read README.md first. My goal is to start a
> Pokémon ROM hack on rh-hideout/pokeemerald-expansion with Claude doing the code work.
> I'm on [Windows/Mac]. My hack idea: [describe]. Help me fill in design/overview.md,
> then walk me through running the setup script and installing the kit into my clone.
